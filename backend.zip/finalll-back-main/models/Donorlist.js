import e from 'express';
import mongoose from 'mongoose';


const DonorSchema = new mongoose.Schema({

    name:String,
    email:String,
    mobile:String,
    bloodgroup:String,


})


const Donorlist= mongoose.model("Donorlist",DonorSchema)
export default  Donorlist;
