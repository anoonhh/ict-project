
import mongoose from 'mongoose';


const RequestSchema = new mongoose.Schema({

    rname:String,
    rage:String,
    remail:String,
    rmobile:String,
    rbloodgroup:String,


})


const RequestList= mongoose.model("Requestlist",RequestSchema)
export default RequestList;
