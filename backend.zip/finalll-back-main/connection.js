import { connect } from 'mongoose';
connect("mongodb+srv://hanoona:hanoona@cluster0.ovamqiv.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0")
.then(()=>
{
    console.log("connected")
})
.catch((err)=>{
    console.log(err)
})