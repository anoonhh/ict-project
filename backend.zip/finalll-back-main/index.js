// import  express, { request }  from "express"
// import dotenv from 'dotenv'
// import mongoose from 'mongoose'
// import cors from 'cors'
// dotenv.config()

// import { UserRouter } from "./routes/user.js"
// import { User } from "./models/User.js"


// // const cors = require('cors')
// const app = express()
// app.use(express.json())
// app.use(cors())
// app.use('/auth',UserRouter)
// app.use(express.json());
// app.use(express.urlencoded({extended:true}));




// mongoose.connect("mongodb+srv://hanoona:hanoona@cluster0.ovamqiv.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0")


// app.post('/signup',(res,req) =>{
//     console.log(req.body)
//     // User.create(req.body)
//     // .then((res)=>{res.send(User)})
    
    
// })



// app.listen(process.env.PORT, () => {
//     console.log("Server is Running")
// })






////////////////////////////////////////////////////////////////////////////////////////////// ul

import express from 'express'

import cors from 'cors'
import UserModel from './models/User.js'
import mongoose from 'mongoose';
import Donorlist from './models/Donorlist.js';
import RequestList from './models/Request.js';
import AdminModel from './models/Admin.js'
// import  './connection.js'


const app=  express();
app.use(express.json())
app.use(cors())

app.use(express.urlencoded({extended:true}))
// app.get('./trail',(_req,res)=>{
//     res.send('trail server')
// })

///////////////

app.listen(3005,()=>{
    console.log('port is up')
})


mongoose.connect("mongodb+srv://hanoona:hanoona@cluster0.ovamqiv.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0")
.then(()=>{
    console.log('connected')
})

//user login


app.post("/login", (req, res) => {
    const {email, password} = req.body;
    UserModel.findOne({email: email})
    .then(user => {
        if(user) {
            if(user.password === password) {
                res.json("exist")
                
            } else {
                res.json("the password is incorrect")

            }
        } else {
            res.json("No record existed")
        }
    })
})

//admin login

app.post("/adminlogin", (req, res) => {
    const {id, password} = req.body;
    AdminModel.findOne({id: id})
    .then(admin => {
        if(admin) {
            if(admin.password === password) {
                res.json("exist")
                
            } else {
                res.json("the password is incorrect")

            }
        } else {
            res.json("No record existed")
        }
    })
})


// add admin
app.post("/add", async (req, res) => {
    try {
      await Donorlist(req.body).save();
      res.send({ message: "Data added!!" });
    } catch (error) {
      console.log(error);
    }
  });
  



app.post('/signup', (req, res) => {
    UserModel.create(req.body)
    .then(user => res.json(user))
    .catch(err => res.json(err))

})


//add 
app.post("/add",async(req,res)=>{
    
    const result= await Donorlist(req.body);
    result.save();
    res.json('data added')
})


app.post("/requestadd",async(req,res)=>{
    
    const result= await RequestList(req.body);
    result.save();
    res.json('data added')
})
//view
app.get('/view',async(_req,res)=>{
    let result = await Donorlist.find();
    res.json(result)
})

app.get('/requestview',async(_req,res)=>{
    let result = await RequestList.find();
    res.json(result)
})


// to delete user
app.delete("/remove/:id", async (req, res) => {
    try {
       await Donorlist.findByIdAndDelete(req.params.id)
       res.send({message:"Deleted successfully!!!"})
    } catch (error) {
        console.log(error)
    }
});

app.delete("/requestremove/:id", async (req, res) => {
    try {
       await RequestList.findByIdAndDelete(req.params.id)
       res.send({message:"Deleted successfully!!!"})
    } catch (error) {
        console.log(error)
    }
});


// to update
app.put("/edit/:id", async (req, res) => {
    try {
      var data = await Donorlist.findByIdAndUpdate(req.params.id, req.body);
    //   res.send({message:'updated successfully',data})
    } catch (error) {
      console.log(error)
    }
  });

  app.put("/requestedit/:id", async (req, res) => {
    try {
      var data = await RequestList.findByIdAndUpdate(req.params.id, req.body);
    //   res.send({message:'updated successfully',data})
    } catch (error) {
      console.log(error)
    }
  });