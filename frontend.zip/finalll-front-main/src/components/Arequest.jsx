


import {
    Button,
    Card,
    CardActions,
    CardContent,
    FormControl,
    Grid,
    InputLabel,
    MenuItem,
    Select,
    Typography,
  } from "@mui/material";
  import { alignProperty } from "@mui/material/styles/cssUtils";
  import axios from "axios";
  import React, { useEffect, useState } from "react";
  import { Link, useNavigate } from "react-router-dom";
  
  const View = () => {
    var [usr, setUsr] = useState([]);
    var history = useNavigate();
    useEffect(() => {
      axios
        .get("http://localhost:3005/requestview")
        .then((res) => {
          console.log(res);
          setUsr(res.data);
        })
        .catch((err) => console.log(err));
    }, []);
  
    const delValue = (id) => {
      console.log(id);
      axios
        .delete("http://localhost:3005/requestremove/" + id)
        .then((res) => {
          alert(res.data.message);
          window.location.reload();
        })
        .catch((err) => console.log(err));
    };
  
    const updateValue = (val) => {
      console.log("up clicked");
      history("/adminrequestform", { state: { val } });
    };
  
  
  
  
    return (
      <div style={{ margin: "2%" }}>
        <br/>
        <center><Typography variant="h2" color={'error'}>Request</Typography><br/><br/>
        <Button  variant="contained" color="error" > <Link to={'/adminrequestform'} style={{ textDecoration: 'none', color: 'white' }} > Request form  </Link>   </Button><br/><br/>
        <Button  variant="contained" color="error"  > <Link to={'/admin'} style={{ textDecoration: 'none', color: 'white' }} >Main  </Link>   </Button>
            </center>
             
             
            
         
       
         
       <br/><br/><br/>
      
            
        <Grid container spacing={2}>
          {usr.map((val, i) => {
            return (
              <Grid item xs={12} md={4}>
                <Card sx={{ minWidth: 275 }} key={i}>
                  <CardContent>
                    <Typography
                      sx={{mb:1.5}}
                      color="text.secondary"
                      gutterBottom
                    >
                      Name:{val.rname}
                    </Typography>
                    <Typography sx={{ mb: 1.5 }} color="text.secondary">
                      Bloodgroup:{val.rbloodgroup}
                    </Typography>
   
                    <Typography sx={{ mb: 1.5 }} color="text.secondary">
                      Email:{val.remail}
                    </Typography>
                    <Typography variant="body2">
                      Mobile:{val.rmobile}
                      <br />
                    </Typography>
                  </CardContent>
                  <CardActions>
                    <Button
                      size="small"
                      onClick={() => {
                        delValue(val._id);
                      }}
                    >
                     <b> Delete</b>
                    </Button>
                    <Button
                      size="small"
                      onClick={() => {
                        updateValue(val);
                      }}
                    >
                     <b> Update</b>
                    </Button>
                  </CardActions>
                </Card>
              </Grid>
            );
          })}
        </Grid>
      </div>
    );
  };
  
  
  
  
  export default View;
  