import React, { useState } from 'react'
import { Button, Input, TextField, Typography } from '@mui/material'

import { Link, useNavigate } from 'react-router-dom'
import axios from "axios"

const Adminlogin = () => {





    const [id, setEmail] = useState('')
    const [password, setPassword] = useState('')
  
    const history = useNavigate();


    const handleSubmit = (e) => {
        e.preventDefault()
        axios.post('http://localhost:3005/adminlogin', {id, password})
        .then(res => {console.log(res)
          if(res.data === "exist") {
              history('/admin')
               
          }
        })
        .catch(err=> console.log(err))
      }
    

  return (
    <div className='bg'>
    <div style={{ paddingTop: '90px' }}></div>
    <div className='sign-up-container'>
      <form onSubmit={handleSubmit} action='post' className='sign-up-form'>
        <Typography variant="h5" color={'error'}>
          <b>Admin Login </b>
        </Typography><br></br><br></br>

        <label htmlFor='email'>Admin Id:</label>
        <input type='text' onChange={(e) => { setEmail(e.target.value) }} placeholder='Email' />


        <label htmlFor='password'>Password:</label>
        <input type='password' onChange={(e) => { setPassword(e.target.value) }} placeholder='********' />
        <button className='signup-button' type='submit' 
        // onClick={handleSubmit}
        >Login </button><br></br>
        {/* <center> <Button >
          <Link to={'/signup'} style={{ textDecoration: 'none', color: 'brown' }}>
            SignUp
          </Link>
        </Button></center> */}

      </form>

    </div></div>
  )
}

export default Adminlogin