import { Button, TextField } from "@mui/material";
import React, { useEffect, useState } from "react";
import axios from "axios";
import { Navigate, useLocation, useNavigate } from "react-router-dom";

const Addadmin = () => {


    var [inputs, setInputs] = useState({ id: "", password: "" });
    var location = useLocation();
    var navigate = useNavigate()
    console.log("loc", location.state);
  
    const inputHandler = (e) => {
      setInputs({ ...inputs, [e.target.name]: e.target.value });
      console.log(inputs);
    };
  
    const addHandler = () => {
      console.log("clicked");
      if (location.state !== null) {
        axios
          .put("http://localhost:3004/edit/"+location.state.val._id,inputs)
          .then((res) => {
              alert(res.data.message)
              navigate('/')
              
          })
          .catch((err) => console.log(err));
      }else{
          axios
          .post("http://localhost:3005/add", inputs)
          .then((res) => {
            console.log(res);
            alert(res.data.message);
            navigate('/')
          })
          .catch((err) => {
            console.log(err);
          });
      }
    };

    
  return (


    <div style={{ marginTop: "3%", textAlign: "center" }}>
      <TextField
        variant="outlined"
        label="Name"
        onChange={inputHandler}
        name="id"
        value={inputs.id}
      />
      <br />
      <br />
      <TextField
        variant="outlined"
        label="Password"
        onChange={inputHandler}
        name="password"
        value={inputs.password}
      />
      <br />
      <br />
      
      <Button variant="contained" color="secondary" onClick={addHandler}>
        Submit
      </Button>
    </div>


    
  )
}

export default Addadmin