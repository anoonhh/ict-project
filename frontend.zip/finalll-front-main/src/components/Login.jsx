import React, { useState } from 'react'
import { Button, Input, TextField, Typography } from '@mui/material'

import { Link, useNavigate } from 'react-router-dom'
import axios from "axios"



function Login  ()  {

 
  // const [username, setUsername] = useState('');
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')

  const history = useNavigate();
  // async function submit(e) {
  //   e.preventDefault();

  //   try {
  //     await axios.post('http://localhost:3005/login', {
  //       email, password
  //     })
  //       .then(res => {
  //         if (res.data = 'exist') {
  //           history('/dashboard', { state: { id: email } })
  //         }
          // else if (res.data = 'notexist') {
          //   alert('User have not sign up')
          // }
  //       })
  //       .catch(e => {
  //         alert('wrong details')
  //         console.log(e);
  //       })


  //   }
  //   catch (e) {
  //     console.log(e)
  //   }
  // }

  const handleSubmit = (e) => {
    e.preventDefault()
    axios.post('http://localhost:3005/login', {email, password})
    .then(res => {console.log(res)
      if(res.data === "exist") {
          history('/dashboard')
           
      }
     
    //  else if (res.data = 'notexist') {
    //   alert('User have not sign up')
    // }
    })
    .catch(err=> console.log(err))
  }



  return (
    <div className='bg'>
      <div style={{ paddingTop: '90px' }}></div>
      <div className='sign-up-container'>
        <form onSubmit={handleSubmit} action='post' className='sign-up-form'>
          <Typography variant="h5" color={'error'}>
            <b> Login </b>
          </Typography><br></br><br></br>

          <label htmlFor='email'>Email:</label>
          <input type='email' onChange={(e) => { setEmail(e.target.value) }} placeholder='Email' />


          <label htmlFor='password'>Password:</label>
          <input type='password' onChange={(e) => { setPassword(e.target.value) }} placeholder='********' />
          <button className='signup-button' type='submit' 
          // onClick={handleSubmit}
          >Login </button><br></br> <br/>
         <p>Don't have an account?</p>
          <center> 
         <br></br>
            <Button >
            <Link to={'/signup'} style={{ textDecoration: 'none', color: 'brown' }}>
              SignUp
            </Link>
          </Button>
          </center>
          <center> <Button   >
          <Link to={'/adminlogin'} style={{ textDecoration: 'none', color: 'brown' }}>
        Admin login
          </Link>
        </Button>
         </center>

        </form>

      </div></div>
  )
}

export default Login