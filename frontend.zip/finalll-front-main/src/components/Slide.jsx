// import React from 'react';
// import { Slide } from 'react-slideshow-image';
// import 'react-slideshow-image/dist/styles.css';
// import './Slide.css';
 
// const Example = () => {
//     const images = [
//         "https://blog.f1000.com/wp-content/uploads/2019/06/Untitled-design-22.png",
//         "https://d3b6u46udi9ohd.cloudfront.net/wp-content/uploads/2022/10/14135243/Blood-Transfusion.jpg",
//         "https://res.cloudinary.com/hype-legal/image/upload/c_fill,g_face:center,h_630,w_1200/clore/images/insights/blood-transfusion.jpg",
//     ];

//     return (
//         <Slide>
//             <div className="each-slide-effect">
//                 <div style={{ 'backgroundImage': `url(${images[0]})` }}>
                  
//                 </div>
//             </div>
//             <div className="each-slide-effect">
//                 <div style={{ 'backgroundImage': `url(${images[1]})` }}>
                  
//                 </div>
//             </div>
//             <div className="each-slide-effect">
//                 <div style={{ 'backgroundImage': `url(${images[2]})` }}>
                  
//                 </div>
//             </div>
//         </Slide>
//     );
// };

// export default Example;
