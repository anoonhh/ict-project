
import { Button, FormControl, InputLabel, MenuItem, NativeSelect, Select, TextField, Typography } from "@mui/material";
import React, { useEffect, useState } from "react";
import axios from "axios";
import { Link, Navigate, useLocation, useNavigate } from "react-router-dom";
const Add = (props) => {
  var [inputs, setInputs] = useState({ name: "",age:"", bloodgroup: "", email: "", mobile: "" ,category:""});
  var location = useLocation();
  var history = useNavigate()
  console.log("loc", location.state);

  const inputHandler = (e) => {
    setInputs({ ...inputs, [e.target.name]: e.target.value });
    console.log(inputs);
  };

  const addHandler = () => {
    console.log("clicked");
    if (location.state !== null) {
      axios
        .put("http://localhost:3005/edit/"+location.state.val._id,inputs)
        .then((res) => {
            // alert(res.data.message)
            history('/admindonor')
            
        })
        .catch((err) => console.log(err));
    }else{
        axios
        .post("http://localhost:3005/add", inputs)
        .then((res) => {
          console.log(res);
          // alert(res.data.message);
          history('/admindonor')
        })
        .catch((err) => {
          console.log(err);
        });
    }
  };

  useEffect(() => {
    if (location.state !== null) {
      setInputs({
        ...inputs,
        name: location.state.val.name,
        bloodgroup: location.state.val.bloodgroup,
        email: location.state.val.email,
        mobile: location.state.val.mobile,
      });
    }
  }, []);


//   const [age, setAge] = React.useState('');


  return (
    
    <div style={{ marginTop: "3%", textAlign: "center" }} >

<div className="sign-up-container">
      <form className="sign-up-form">
      <Typography  color={'error'}><b><h4>Donate form</h4></b></Typography>
 <label htmlFor='name'>Name:</label>
<input type='text' onChange={inputHandler} label="name" name='name' value={inputs.name}/>


{/* 
<label htmlFor='name'>Age:</label>
<input type='age' onChange={inputHandler} label="age" name='age' value={inputs.age}/> */}

     
       <label htmlFor='text'>Bloodgroup</label>
<input type='text' onChange={inputHandler} label="bloodgroup" name='bloodgroup' value={inputs.bloodgroup}/>








<label htmlFor='email'>Email:</label>
<input type='email' onChange={inputHandler} label="email" name='email' value={inputs.email}/><br/>

     
     

<label htmlFor='number'>Mobile</label>
<input type='text' onChange={inputHandler} label="Mobile" name='mobile' value={inputs.mobile}/>
{/* 
<label htmlFor='name'>category:</label>
<input type='select' onChange={inputHandler} label="category" name='category' value={inputs.category}/> */}
{/* <FormControl sx={{ m: 1, minWidth: 120 }} size="small">
      <InputLabel id="demo-select-small-label">Age</InputLabel>
      <Select
        labelId="demo-select-small-label"
        id="demo-select-small"
        value={inputs.category}
        label="category"
        onChange={inputHandler}
        name=""
      >
        <MenuItem value="">
          <em>None</em>
        </MenuItem>
        <MenuItem value={10}>Ten</MenuItem>
        <MenuItem value={20}>Twenty</MenuItem>
        <MenuItem value={30}>Thirty</MenuItem>
      </Select>
    </FormControl> */}

      
      <Button className="signup-button " color="error"  variant="contained"  onClick={addHandler}>
        Submit
      </Button>
      <Button >
            <Link to={'/admindonor'} style={{ textDecoration: 'none', color: 'brown' }}>
              Donor List
            </Link>
          </Button>
      </form>
      </div>
    </div>
  );
};

export default Add;
