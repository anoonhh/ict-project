// import { Button, FormControl, FormControlLabel, FormLabel, InputLabel, MenuItem, Radio, RadioGroup, Select, TextField, Typography } from '@mui/material'
// import React from 'react'
// import { useLocation } from 'react-router-dom'

// const Home = () => {
//   const [age, setAge] = React.useState('');

//   // const handleChange = (event) => {
//   //   setAge(event.target.value);
//   // };


//   // const location=useLocation()


//   return (
//     <div style={{ paddingTop: "50px", marginLeft: "10px" }} >

// {/* <h1>Hello {location.state.id}</h1> */}
// <center>
//       <Typography color={'error'}>  <h2>Blood Request</h2> </Typography>
//       <TextField placeholder='enter your name' id="outlined-basic" label="Full Name" variant="outlined" /><br/><br/>
//       <TextField placeholder='enter your mail' id="outlined-basic" label="Email" variant="outlined" /><br></br><br/>
//       <TextField placeholder='enter your location' id="outlined-basic" label="Location" variant="outlined" /><br/><br/>
//       <TextField placeholder='enter your city' id="outlined-basic" label="city" variant="outlined" /> <br></br><br></br>
//       <TextField placeholder='enter your Phone number' id="outlined-basic" label="Phone number" variant="outlined" /> <br></br><br/>
//       <FormControl sx={{ m: 1, minWidth: 130 }}>
//         <InputLabel id="demo-simple-select-label">blood group</InputLabel>
//         <Select
//           labelId="demo-simple-select-label"
//           id="demo-simple-select"
//           value={age}
//           label="blood group"
//         //   onChange={handleChange}
//         >
//           <MenuItem value={10}>A+ve</MenuItem>
//           <MenuItem value={20}>A-ve</MenuItem>
//           <MenuItem value={30}>B+ve</MenuItem>
//           <MenuItem value={30}>B-ve</MenuItem>
//           <MenuItem value={30}>AB+ve</MenuItem>
//           <MenuItem value={30}>AB-ve</MenuItem>
//           <MenuItem value={30}>O+ve</MenuItem>
//           <MenuItem value={30}>B+ve</MenuItem>
//           <MenuItem value={30}>B+ve</MenuItem>
//         </Select>
//       </FormControl>
     
//       <h3>Gender</h3><br></br>
//       <FormControl>

//         <RadioGroup
//           row
//           aria-labelledby="demo-row-radio-buttons-group-label"
//           name="row-radio-buttons-group"
//         >
//           <FormControlLabel value="female" control={<Radio />} label="Female" />
//           <FormControlLabel value="male" control={<Radio />} label="Male" />
//           <FormControlLabel value="other" control={<Radio />} label="Other" />

//         </RadioGroup>
//       </FormControl><br></br><br></br>
//       <Button variant="contained" color="error">submit</Button>


//       </center>


//     </div>
//   )
// }

// export default Home


import {
  Button,
  Card,
  CardActions,
  CardContent,
  FormControl,
  Grid,
  InputLabel,
  MenuItem,
  Select,
  Typography,
} from "@mui/material";
import { alignProperty } from "@mui/material/styles/cssUtils";
import axios from "axios";
import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";

const View = () => {
  var [usr, setUsr] = useState([]);
  var history = useNavigate();
  useEffect(() => {
    axios
      .get("http://localhost:3005/view")
      .then((res) => {
        console.log(res);
        setUsr(res.data);
      })
      .catch((err) => console.log(err));
  }, []);

  const delValue = (id) => {
    console.log(id);
    axios
      .delete("http://localhost:3005/remove/" + id)
      .then((res) => {
        alert(res.data.message);
        window.location.reload();
      })
      .catch((err) => console.log(err));
  };

  const updateValue = (val) => {
    console.log("up clicked");
    history("/donor", { state: { val } });
  };




  return (
    <div style={{ margin: "2%" }}>
      <br/>
      <center><Typography variant="h2" color={'error'}>Welcome to Donor Dashboard</Typography><br/><br/>

         <Button  variant="contained" color="error" > <Link to={'/donor'} style={{ textDecoration: 'none', color: 'White' }} > Donor form  </Link>   </Button><br/><br/>
         <Button variant="contained" color="error"> <Link to={'/request'} style={{ textDecoration: 'none', color: 'white' }} > Request form  </Link>   </Button> </center>
           
           
          
       
     
       
     <br/><br/><br/>
    
          
      <Grid container spacing={2}>
        {usr.map((val, i) => {
          return (
            <Grid item xs={12} md={4}>
              <Card sx={{ minWidth: 275 }} key={i}>
                <CardContent>
                  <Typography
                    sx={{mb:1.5}}
                    color="text.secondary"
                    gutterBottom
                  >
                    Name:{val.name}
                  </Typography>
                  <Typography sx={{ mb: 1.5 }} color="text.secondary">
                    Bloodgroup:{val.bloodgroup}
                  </Typography>
 
                  <Typography sx={{ mb: 1.5 }} color="text.secondary">
                    Email:{val.email}
                  </Typography>
                  <Typography variant="body2">
                    Mobile:{val.mobile}
                    <br />
                  </Typography>
                </CardContent>
                {/* <CardActions> */}
                  {/* <Button
                    size="small"
                    onClick={() => {
                      delValue(val._id);
                    }}
                  >
                    Del
                  </Button>
                  <Button
                    size="small"
                    onClick={() => {
                      updateValue(val);
                    }}
                  >
                    Up
                  </Button> */}
                {/* </CardActions> */}
              </Card>
            </Grid>
          );
        })}
      </Grid>
    </div>
  );
};




export default View;
