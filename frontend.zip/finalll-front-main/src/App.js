import React from 'react'
import Main from './components/Main'
import Login from './components/Login'
import Bar from './components/Bar'
import Signup from './components/Signup'
import { Route, Routes } from 'react-router-dom'
import Dashboard from './components/Dashboard'
import Donorlist from './components/Donorlist'
import Request from './components/Request'
import Admin from './components/Admin'
import Admindonor from './components/Admindonor'
import Admindonorform from './components/Admindonorform'
import Arequestform from './components/Arequestform'
import Arequest from './components/Arequest'
import Addadmin from './components/Addadmin'
import Adminlogin from './components/Adminlogin'

const App = () => {
  return (
    <div> 
<Bar/>

<Routes>
<Route path='/' element={<Main/>}/>
<Route path='/login' element={<Login/>}/>
<Route path='/signup' element={<Signup/>}/>
<Route path='/dashboard' element={<Dashboard/>}/>
<Route path='/donor' element={<Donorlist/>}/>
<Route path='/request' element={<Request/>}/>
<Route path='/admin' element={<Admin/>}/>
<Route path='/admindonor' element={<Admindonor/>}/>
<Route path='/admindonorform' element={<Admindonorform/>}/>
<Route path='/adminrequestform' element={<Arequestform/>}/>
<Route path='/adminrequest' element={<Arequest/>}/>




<Route path='/addadmin' element={<Addadmin/>}/>

<Route path='/adminlogin' element={<Adminlogin/>}/>


 





</Routes>
    </div>
  )
}

export default App